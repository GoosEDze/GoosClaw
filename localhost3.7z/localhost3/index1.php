<?php
session_start();
$conn = mysqli_connect("localhost", "root", "root", "mynews");
if (!$conn) {
    die("Ошибка: " . mysqli_connect_error());
}
$sql = "SELECT id, title FROM `new` ";
$result = mysqli_query($conn, $sql);
if (isset($_GET["id"])) {
    $id = $_GET["id"];
}
$newww = "SELECT * FROM `new`";
$newResult = mysqli_query($conn, $newww);

?>
<!DOCTYPE html>
<html lang="ru">


<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="styles/style1.css">
    <title>Новости</title>
</head>
    <style>

        body { background-image: url(img/bg.jpg);}
        </style>

<div class="main">
    <header class="head">
        <div class="left">
            <div class="logo">
                <img src="img/logo.jpg" class="respons" alt="">
                <span class="header_info">Новости Волгограда<br> На связи 24/7</span>
                <a href='index2.php'> Редактор сайта </a> <br>
                <?php
                if (isset($_SESSION["adminid"])) {
                    $currentID = $_SESSION["adminid"];
                    $loginSelect = "SELECT login FROM `auth` WHERE id = '$currentID'";
                    $loginResult = mysqli_query($conn, $loginSelect);
                    $loginFetch = mysqli_fetch_array($loginResult);

                    echo "Привет," . $loginFetch['login'];
                } else {
                    echo " Привет admin<a href='index.php'>" . "Выйти" . "</a>";
                }
                ?>
            </div>
            <div class="cont">
                <?php
                foreach ($newResult as $newRow) {
                    $show_img = base64_encode($newRow['image']);
                    echo "<div id='new_block'>";
                    ?>
                    <?php
                    echo "<h2>" . $newRow['name'] . "</h2>";
                    ?>
                    <img id="new_image" src= "data:image/jpeg;base64, <?php echo $show_img ?> "width="200" height="200" border="10px bgcolor=#483D8B" alt="">
                    <?php
                    echo "<p>" . $newRow['text'] . "</p>";
                    echo "<h3><a href='scription1.php?id=" . $newRow['id'] ."'> Подробнее </a></h3>";
                    echo "</div>";
                }
                ?>
            </div>
        </div>
        <footer>
            <div>News© 2022</div>
        </footer>
</body>
</html>
