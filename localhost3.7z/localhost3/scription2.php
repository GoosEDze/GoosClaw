<?php
$conn = mysqli_connect("localhost", "root", "root", "mynews");
if (!$conn) {
    die("Ошибка: " . mysqli_connect_error());
}
$sql = "SELECT id, title FROM `new` ";
$result = mysqli_query($conn, $sql);
if (isset($_GET["id"])) {
    $id = $_GET["id"];
}
$newId = mysqli_real_escape_string($conn, $_GET["id"]);
$newFullSelection = "SELECT * FROM `new` WHERE id = '$newId'";
$newResult = mysqli_query($conn, $newFullSelection);
?>
<!DOCTYPE html>
<html lang="ru">


<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="styles/style1.css">
    <title>Новости</title>
</head>
<style>

        body { background-image: url(img/bg.jpg);}
        </style>
<div class="main">
    <header class="head">
        <div class="left">
            <div class="logo">
                <img src="img/logo.jpg" class="respons" alt="">
                <span class="header_info">Новости Волгограда<br> На связи 24/7</span>

            </div>
    <div class="cont">
    <?php
        foreach ($newResult as $newRow) {
            $show_img = base64_encode($newRow['image']);
            echo "<div id='new_block'>";
            ?>
            <div>
            <form method = "POST">
            <?php echo "<input type='text' name='name' value='". $newRow['name']."'>" ?>  
            
        </div>
            <img id="new_image" src= "data:image/jpeg;base64, <?php echo $show_img ?> "width="200" height="200" border="10px bgcolor=#483D8B" alt=""><br>
            <input type="file" name="filename"><br><br>
            <?php echo "<textarea name='text' cols=15' rows='5'>" . $newRow['text']. "</textarea>" ?> <br>
            <?php echo "<textarea name='full' cols='30' rows='10'>" . $newRow['full']. "</textarea>" ?>
            <?php
            echo "<h3><a href='index2.php?id=" . $newRow['id'] ."'> Назад </a></h3>";
            echo "</div>";
        }
        ?>
                    <p><input type="submit" value="Сохранить"></p>
                    </form>
            <?php
            if(isset($_POST["name"]) && isset($_POST["text"]) && isset($_POST["full"]) && isset($_GET["id"])){
                $name = $_POST["name"];
                $text = $_POST["text"];
                $full = $_POST["full"];
                $id = $_GET["id"];
                $newred = "UPDATE `new` SET `name`='$name', `text` = '$text', `full` = '$full' WHERE id = '$id'";
                if ($conn->query($newred)) {
                    echo "<script>alert(\"Новость отредактированна\");</script>";
                } else {
                    echo "Ошибка: " . $conn->error;
                }
            }
            ?>                    
    </div>
        </div>
        <footer>
            <div>News© 2022</div>
        </footer>
</body>
</html>